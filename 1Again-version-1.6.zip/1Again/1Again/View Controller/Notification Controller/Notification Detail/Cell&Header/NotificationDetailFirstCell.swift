//
//  NotificationDetailFirstCell.swift
//  1Again
//
//  Created by Nam Phong on 7/16/15.
//  Copyright (c) 2015 Phong Nguyen Nam. All rights reserved.
//

import UIKit
protocol NotificationDetailFirstCellDelegate {
    func clickButtonAtIndex(index: Int)
}

class NotificationDetailFirstCell: UITableViewCell {
    
    var delegate: NotificationDetailFirstCellDelegate?

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    @IBAction func btnNothankClicked(sender: AnyObject) {
        self.delegate?.clickButtonAtIndex(0)
    }
    
    @IBAction func btnSaveClicked(sender: AnyObject) {
        self.delegate?.clickButtonAtIndex(1)
    }
    
    @IBAction func btnInterestedClicked(sender: AnyObject) {
        self.delegate?.clickButtonAtIndex(2)
    }
}
