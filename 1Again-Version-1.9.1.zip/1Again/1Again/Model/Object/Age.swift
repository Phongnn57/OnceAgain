//
//  Age.swift
//  1Again
//
//  Created by Nam Phong on 7/18/15.
//  Copyright (c) 2015 Phong Nguyen Nam. All rights reserved.
//

import UIKit

class Age {
    var ageID: String?
    var ageDescription: String?

    init() {
        self.ageID = ""
        self.ageDescription = ""
    }
}